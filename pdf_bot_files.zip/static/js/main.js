/**
 * ملف الجافاسكريبت الرئيسي لتطبيق PDF Bot
 */

document.addEventListener('DOMContentLoaded', function() {
    // تهيئة tooltips 
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function(tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // تهيئة popovers
    const popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    popoverTriggerList.map(function(popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });

    // استدعاء واجهة برمجة الإحصائيات للوحة التحكم
    fetchDashboardStats();
    
    // مستمع للأزرار التبديلية في لوحة التحكم
    const chartTimeRangeButtons = document.querySelectorAll('[data-chart-range]');
    if (chartTimeRangeButtons) {
        chartTimeRangeButtons.forEach(button => {
            button.addEventListener('click', function(e) {
                e.preventDefault();
                const range = this.getAttribute('data-chart-range');
                updateChartData(range);
            });
        });
    }
});

/**
 * استدعاء إحصائيات لوحة التحكم
 */
function fetchDashboardStats() {
    // إذا كنا في صفحة لوحة التحكم
    if (document.querySelector('#activityChart')) {
        fetch('/api/stats')
            .then(response => response.json())
            .then(data => {
                // استخدام البيانات لتحديث أي عناصر إحصائية حية
                updateLiveStats(data);
            })
            .catch(error => {
                console.error('خطأ في استدعاء الإحصائيات:', error);
            });
    }
}

/**
 * تحديث الإحصائيات المباشرة في لوحة التحكم
 */
function updateLiveStats(data) {
    // إضافة منطق لتحديث العناصر المباشرة بناءً على البيانات
    // على سبيل المثال:
    const serverStatusEl = document.querySelector('#server-status');
    if (serverStatusEl) {
        serverStatusEl.textContent = data.server_status === 'online' ? 'متصل' : 'غير متصل';
        serverStatusEl.className = data.server_status === 'online' ? 'text-success' : 'text-danger';
    }
}

/**
 * تحديث بيانات المخطط عند تغيير النطاق الزمني
 */
function updateChartData(range) {
    // يمكن تنفيذ منطق لاستدعاء بيانات مختلفة بناءً على النطاق الزمني المحدد
    console.log(`تحديث المخطط للنطاق الزمني: ${range}`);
    // في التنفيذ الحقيقي: استدعاء بيانات من النقطة النهائية المناسبة
}

/**
 * معالجة تقدم العمليات (مثل تحويل PDF)
 */
function trackProgress(operationId) {
    // استدعاء حالة العملية كل ثانية
    const progressInterval = setInterval(() => {
        fetch(`/api/operations/${operationId}/status`)
            .then(response => response.json())
            .then(data => {
                updateProgressUI(data);
                if (data.status === 'completed' || data.status === 'failed') {
                    clearInterval(progressInterval);
                    handleOperationCompletion(data);
                }
            })
            .catch(error => {
                console.error('خطأ في تتبع التقدم:', error);
                clearInterval(progressInterval);
            });
    }, 1000);
}

/**
 * تحديث واجهة المستخدم للتقدم
 */
function updateProgressUI(data) {
    // تحديث شريط التقدم أو النص بناءً على بيانات العملية
    const progressBar = document.querySelector('.progress-bar');
    if (progressBar) {
        progressBar.style.width = `${data.progress}%`;
        progressBar.setAttribute('aria-valuenow', data.progress);
        document.querySelector('.progress-text').textContent = `${data.progress}%`;
    }
}

/**
 * معالجة اكتمال العملية
 */
function handleOperationCompletion(data) {
    // عرض رسالة نجاح أو فشل العملية
    const alertType = data.status === 'completed' ? 'success' : 'danger';
    const alertMessage = data.status === 'completed' 
        ? 'تم إكمال العملية بنجاح!' 
        : `فشلت العملية: ${data.error}`;
    
    showAlert(alertType, alertMessage);
    
    // إذا كانت هناك نتيجة، عرض رابط التنزيل أو اتخاذ إجراء
    if (data.result && data.result.downloadUrl) {
        document.querySelector('#download-link').href = data.result.downloadUrl;
        document.querySelector('#download-section').classList.remove('d-none');
    }
}

/**
 * عرض تنبيه للمستخدم
 */
function showAlert(type, message) {
    const alertPlaceholder = document.querySelector('#alert-placeholder');
    if (alertPlaceholder) {
        const wrapper = document.createElement('div');
        wrapper.innerHTML = `
            <div class="alert alert-${type} alert-dismissible fade show" role="alert">
                ${message}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="إغلاق"></button>
            </div>
        `;
        alertPlaceholder.appendChild(wrapper);
        
        // إزالة التنبيه تلقائيًا بعد 5 ثوانٍ
        setTimeout(() => {
            const alert = bootstrap.Alert.getInstance(wrapper.querySelector('.alert'));
            if (alert) {
                alert.close();
            } else {
                wrapper.querySelector('.alert').remove();
            }
        }, 5000);
    }
}