"""
نقطة دخول لتطبيق الويب PDF Bot
"""
import os
import logging
from app import app, db
from models import init_db

# إعداد التسجيل
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('web_app.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# تهيئة قاعدة البيانات
with app.app_context():
    try:
        init_db()
        logger.info("تم تهيئة قاعدة البيانات بنجاح")
    except Exception as e:
        logger.error(f"خطأ في تهيئة قاعدة البيانات: {e}")

# يمكن استيراد هذا الملف للوصول إلى كائن app