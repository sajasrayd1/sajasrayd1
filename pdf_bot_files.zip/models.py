"""
نماذج قاعدة البيانات للبوت
"""
import os
from datetime import datetime
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import Column, Integer, String, Boolean, DateTime, Float, ForeignKey, Text, JSON
from sqlalchemy.orm import relationship

from app import db


class User(db.Model):
    """نموذج المستخدم"""
    __tablename__ = 'users'
    
    id = Column(Integer, primary_key=True)
    telegram_id = Column(String(50), unique=True, nullable=False)
    username = Column(String(100))
    first_name = Column(String(100))
    last_name = Column(String(100))
    language_code = Column(String(10), default='ar')
    is_admin = Column(Boolean, default=False)
    is_premium = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    last_activity = Column(DateTime, default=datetime.utcnow)
    settings = Column(JSON, default={})
    
    # العلاقات
    documents = relationship("Document", back_populates="user", cascade="all, delete-orphan")
    templates = relationship("Template", back_populates="user", cascade="all, delete-orphan")
    activities = relationship("UserActivity", back_populates="user", cascade="all, delete-orphan")
    
    def __repr__(self):
        return f"<User {self.username} ({self.telegram_id})>"


class Document(db.Model):
    """نموذج المستندات"""
    __tablename__ = 'documents'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    title = Column(String(255))
    file_path = Column(String(255), nullable=False)
    file_type = Column(String(10), default='pdf')  # pdf, image, docx, etc
    file_size = Column(Integer)  # in bytes
    pages_count = Column(Integer, default=1)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    is_encrypted = Column(Boolean, default=False)
    document_metadata = Column(JSON, default={})
    
    # العلاقات
    user = relationship("User", back_populates="documents")
    images = relationship("Image", back_populates="document", cascade="all, delete-orphan")
    
    def __repr__(self):
        return f"<Document {self.title} (ID: {self.id})>"


class Image(db.Model):
    """نموذج الصور"""
    __tablename__ = 'images'
    
    id = Column(Integer, primary_key=True)
    document_id = Column(Integer, ForeignKey('documents.id'), nullable=False)
    file_path = Column(String(255), nullable=False)
    order_index = Column(Integer, default=0)  # ترتيب الصورة في المستند
    width = Column(Integer)
    height = Column(Integer)
    created_at = Column(DateTime, default=datetime.utcnow)
    processed = Column(Boolean, default=False)
    image_metadata = Column(JSON, default={})  # مثل إعدادات السطوع، التباين، التدوير
    
    # العلاقات
    document = relationship("Document", back_populates="images")
    
    def __repr__(self):
        return f"<Image {self.id} (Document ID: {self.document_id})>"


class Template(db.Model):
    """نموذج القوالب"""
    __tablename__ = 'templates'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    name = Column(String(100), nullable=False)
    settings = Column(JSON, nullable=False)  # إعدادات القالب
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    is_public = Column(Boolean, default=False)  # هل القالب متاح للمشاركة
    
    # العلاقات
    user = relationship("User", back_populates="templates")
    
    def __repr__(self):
        return f"<Template {self.name} (User ID: {self.user_id})>"


class UserActivity(db.Model):
    """نموذج نشاط المستخدم"""
    __tablename__ = 'user_activities'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    activity_type = Column(String(50), nullable=False)  # create_pdf, ocr, merge, split, etc
    details = Column(JSON)  # تفاصيل النشاط
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # العلاقات
    user = relationship("User", back_populates="activities")
    
    def __repr__(self):
        return f"<UserActivity {self.activity_type} (User ID: {self.user_id})>"


class Subscription(db.Model):
    """نموذج الاشتراكات"""
    __tablename__ = 'subscriptions'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    plan_name = Column(String(50), nullable=False)  # basic, premium, professional
    start_date = Column(DateTime, nullable=False)
    end_date = Column(DateTime, nullable=False)
    is_active = Column(Boolean, default=True)
    payment_id = Column(String(100))  # معرف الدفع
    payment_amount = Column(Float)
    payment_currency = Column(String(10))
    
    # العلاقة
    user = relationship("User")
    
    def __repr__(self):
        return f"<Subscription {self.plan_name} (User ID: {self.user_id})>"


class SystemConfig(db.Model):
    """نموذج إعدادات النظام"""
    __tablename__ = 'system_configs'
    
    id = Column(Integer, primary_key=True)
    key = Column(String(50), unique=True, nullable=False)
    value = Column(Text)
    description = Column(Text)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f"<SystemConfig {self.key}>"


class CloudStorage(db.Model):
    """نموذج التخزين السحابي"""
    __tablename__ = 'cloud_storages'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    provider = Column(String(50), nullable=False)  # google_drive, dropbox, onedrive
    access_token = Column(Text)
    refresh_token = Column(Text)
    token_expires_at = Column(DateTime)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    settings = Column(JSON, default={})
    
    # العلاقة
    user = relationship("User")
    
    def __repr__(self):
        return f"<CloudStorage {self.provider} (User ID: {self.user_id})>"


# إنشاء جميع الجداول عند بدء التطبيق
def init_db():
    db.create_all()