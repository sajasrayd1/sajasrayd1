#!/usr/bin/env python3
"""
سكريبت لتشغيل بوت التيليجرام.
هذا الملف يساعدك على تشغيل البوت خارج Replit.
"""
import os
import sys
import logging
import subprocess
from pathlib import Path

# إعداد التسجيل
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('pdf_bot.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

def check_environment():
    """التحقق من البيئة ومتطلبات التشغيل"""
    # التحقق من وجود توكن البوت
    if 'TELEGRAM_BOT_TOKEN' not in os.environ:
        try:
            # محاولة قراءة الملف .env إذا كان موجوداً
            env_path = Path('.env')
            if env_path.exists():
                logger.info("جاري قراءة ملف .env...")
                with open(env_path, 'r') as f:
                    for line in f:
                        if line.strip() and not line.startswith('#'):
                            key, value = line.strip().split('=', 1)
                            os.environ[key] = value
                logger.info("تم قراءة ملف .env بنجاح")
            else:
                logger.warning("ملف .env غير موجود")
        except Exception as e:
            logger.error(f"خطأ في قراءة ملف .env: {e}")
    
    # التحقق مرة أخرى بعد محاولة قراءة الملف
    if 'TELEGRAM_BOT_TOKEN' not in os.environ:
        logger.error("متغير TELEGRAM_BOT_TOKEN غير موجود. يرجى تعيينه في متغيرات البيئة أو في ملف .env.")
        print("\n" + "=" * 60)
        print("خطأ: توكن بوت التيليجرام غير موجود!")
        print("يرجى تنفيذ أحد الإجراءات التالية:")
        print("1. إنشاء ملف .env وإضافة: TELEGRAM_BOT_TOKEN=your_token_here")
        print("2. تعيين متغير البيئة: export TELEGRAM_BOT_TOKEN=your_token_here")
        print("=" * 60 + "\n")
        return False
    
    # التحقق من المجلدات المطلوبة
    for folder in ['uploads', 'temp']:
        if not os.path.exists(folder):
            try:
                os.makedirs(folder)
                logger.info(f"تم إنشاء مجلد {folder}")
            except Exception as e:
                logger.error(f"خطأ في إنشاء مجلد {folder}: {e}")
                return False
    
    return True

def run_web_app():
    """تشغيل تطبيق الويب"""
    try:
        if 'gunicorn' in sys.modules:
            cmd = ["gunicorn", "--bind", "0.0.0.0:5000", "--reuse-port", "--reload", "main:app"]
        else:
            cmd = [sys.executable, "-m", "flask", "--app", "main", "run", "--host=0.0.0.0", "--port=5000"]
        
        logger.info(f"جاري تشغيل تطبيق الويب باستخدام: {' '.join(cmd)}")
        subprocess.Popen(cmd)
        logger.info("تم بدء تشغيل تطبيق الويب")
    except Exception as e:
        logger.error(f"خطأ في تشغيل تطبيق الويب: {e}")

def run_bot():
    """تشغيل بوت التيليجرام"""
    try:
        logger.info("جاري تشغيل بوت التيليجرام...")
        # استيراد وتشغيل البوت
        from bot import main
        main()
    except Exception as e:
        logger.error(f"خطأ في تشغيل البوت: {e}")

def main():
    """الدالة الرئيسية"""
    print("=" * 60)
    print("PDF Bot - مساعد تحويل الصور إلى PDF")
    print("=" * 60)
    
    if not check_environment():
        sys.exit(1)
    
    # السؤال عما إذا كان المستخدم يريد تشغيل تطبيق الويب أيضاً
    run_webapp = input("هل ترغب في تشغيل تطبيق الويب أيضاً؟ (y/n): ").strip().lower() == 'y'
    
    if run_webapp:
        run_web_app()
        print("\n" + "=" * 60)
        print("تم بدء تشغيل تطبيق الويب على:")
        print("http://localhost:5000")
        print("=" * 60 + "\n")
    
    # تشغيل البوت
    print("\n" + "=" * 60)
    print("جاري تشغيل بوت التيليجرام...")
    print("للإيقاف، اضغط Ctrl+C")
    print("=" * 60 + "\n")
    run_bot()

if __name__ == "__main__":
    main()