"""
نقطة دخول بوت تيليجرام لتحويل الصور إلى PDF
"""
from simple_telegram_bot import main_loop
import logging

if __name__ == "__main__":
    # إعداد التسجيل
    logging.basicConfig(
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        level=logging.INFO,
        handlers=[
            logging.FileHandler('pdf_bot.log'),
            logging.StreamHandler()
        ]
    )
    logger = logging.getLogger(__name__)
    
    try:
        logger.info("بدء تشغيل بوت تحويل الصور إلى PDF...")
        main_loop()
    except KeyboardInterrupt:
        logger.info("تم إيقاف البوت بواسطة المستخدم")
    except Exception as e:
        logger.error(f"حدث خطأ أثناء تشغيل البوت: {e}", exc_info=True)