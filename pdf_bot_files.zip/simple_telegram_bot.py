"""
بوت تليجرام بسيط لتحويل الصور إلى ملفات PDF
باستخدام منظم عملي بدلاً من استخدام مكتبة python-telegram-bot
"""
import os
import json
import requests
import logging
import time
import threading
from datetime import datetime
import traceback
import pdf_bot
import re

# إعداد التسجيل
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO,
    handlers=[
        logging.FileHandler('pdf_bot.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# ============ إعدادات البوت ============
TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "8150724834:AAGSs_NbpgreMKwDuw07D1bESSVoope1jH8")
API_URL = f"https://api.telegram.org/bot{TOKEN}"
ADMIN_IDS = [6999077939]  # قائمة بمشرفي البوت
MAX_IMAGES_PER_USER = 30  # الحد الأقصى للصور
MAX_FILE_SIZE_MB = 10  # الحد الأقصى لحجم الملف
SUPPORTED_LANGUAGES = ["ar", "en", "fr", "es", "de", "ru", "tr"]

# تخزين بيانات المستخدمين
users_data = {}
bot_settings = {
    "maintenance": False,
    "free_mode": True,
    "allowed_users": [],
    "watermark_text": "Created by PDF Bot",
    "start_time": datetime.now(),
    "total_pdfs": 0,
    "total_ocr": 0,
    "total_merges": 0,
    "total_splits": 0,
    "default_lang": "ar",
    "notification_enabled": False,
    "version": "2.0.0"
}

# ملفات النظام
USER_DATA_FILE = "user_data.json"
BOT_SETTINGS_FILE = "bot_settings.json"

# محاولة تحميل البيانات المحفوظة
try:
    if os.path.exists(USER_DATA_FILE):
        with open(USER_DATA_FILE, 'r', encoding='utf-8') as f:
            users_data = json.load(f)
            logger.info(f"تم تحميل بيانات {len(users_data)} مستخدم")
except Exception as e:
    logger.error(f"خطأ في تحميل بيانات المستخدمين: {e}")

try:
    if os.path.exists(BOT_SETTINGS_FILE):
        with open(BOT_SETTINGS_FILE, 'r', encoding='utf-8') as f:
            loaded_settings = json.load(f)
            # دمج الإعدادات المحملة مع الإعدادات الافتراضية
            for key, value in loaded_settings.items():
                if key != "start_time":  # عدم تحميل وقت البدء
                    bot_settings[key] = value
            logger.info("تم تحميل إعدادات البوت")
except Exception as e:
    logger.error(f"خطأ في تحميل إعدادات البوت: {e}")

# إعادة تعيين وقت البدء
bot_settings["start_time"] = datetime.now()

# تم تهيئة التسجيل بالفعل في بداية الملف

# ============ وظائف HTTP ============
def get_updates(offset=None, timeout=30):
    """الحصول على تحديثات من تليجرام"""
    params = {"timeout": timeout, "allowed_updates": ["message", "callback_query"]}
    if offset:
        params["offset"] = offset
    response = requests.get(f"{API_URL}/getUpdates", params=params)
    return response.json().get("result", [])

def send_message(chat_id, text, reply_markup=None, parse_mode=None):
    """إرسال رسالة نصية"""
    params = {"chat_id": chat_id, "text": text}
    if reply_markup:
        params["reply_markup"] = json.dumps(reply_markup)
    if parse_mode:
        params["parse_mode"] = parse_mode
    response = requests.post(f"{API_URL}/sendMessage", json=params)
    return response.json()

def send_chat_action(chat_id, action="typing"):
    """إرسال حالة (مثل الكتابة)"""
    params = {"chat_id": chat_id, "action": action}
    response = requests.post(f"{API_URL}/sendChatAction", json=params)
    return response.json()

def send_document(chat_id, document_path, caption=None):
    """إرسال ملف"""
    params = {"chat_id": chat_id}
    if caption:
        params["caption"] = caption
    
    with open(document_path, "rb") as document:
        files = {"document": document}
        response = requests.post(f"{API_URL}/sendDocument", data=params, files=files)
    
    return response.json()

def get_file(file_id):
    """الحصول على معلومات ملف"""
    params = {"file_id": file_id}
    response = requests.get(f"{API_URL}/getFile", params=params)
    return response.json().get("result", {})

def download_file(file_path, local_path):
    """تنزيل ملف من خادم تليجرام"""
    file_url = f"https://api.telegram.org/file/bot{TOKEN}/{file_path}"
    response = requests.get(file_url)
    
    with open(local_path, "wb") as f:
        f.write(response.content)
    
    return local_path

# ============ وظائف المعالجة ============
def handle_command(message):
    """معالجة الأوامر"""
    text = message.get("text", "")
    chat_id = message["chat"]["id"]
    user_id = message["from"]["id"]
    first_name = message["from"]["first_name"]
    
    # التحقق من أمر البدء
    if text.startswith("/start"):
        return handle_start(chat_id, user_id, first_name)
    
    # التحقق من أمر الإلغاء
    elif text.startswith("/cancel"):
        return handle_cancel(chat_id, user_id)
    
    # التحقق من أمر معلومات البوت
    elif text.startswith("/about"):
        return handle_about(chat_id)
    
    # التحقق من أمر لوحة التحكم
    elif text.startswith("/admin"):
        return handle_admin_command(chat_id, user_id)
    
    # التحقق من أمر إنشاء PDF
    elif text.startswith("/pdf"):
        return handle_create_pdf(chat_id, user_id)
    
    # معالجة النص العادي كأزرار
    else:
        return handle_text_button(chat_id, user_id, text)

def handle_start(chat_id, user_id, first_name):
    """معالجة أمر البدء"""
    logger.info(f"المستخدم {first_name} (معرف: {user_id}) بدأ استخدام البوت")
    
    # التحقق مما إذا كان وضع الصيانة قيد التشغيل
    if bot_settings["maintenance"] and not pdf_bot.is_admin(user_id, ADMIN_IDS):
        send_message(chat_id, "البوت تحت الصيانة، الرجاء المعاودة لاحقاً")
        return
    
    # التحقق مما إذا كان المستخدم مسموحًا له في الوضع المقيد
    if not bot_settings["free_mode"] and user_id not in bot_settings["allowed_users"] and not pdf_bot.is_admin(user_id, ADMIN_IDS):
        send_message(chat_id, "عذراً، البوت متاح فقط للمستخدمين المصرح لهم")
        return
    
    # تهيئة بيانات المستخدم
    pdf_bot.init_user_data(users_data, user_id, first_name)
    
    # مسح أي صور سابقة
    users_data[user_id]["images"] = []
    pdf_bot.cleanup_user_files(user_id)
    
    # إنشاء لوحة مفاتيح القائمة الرئيسية
    keyboard = {
        "keyboard": [
            [{"text": "إرسال الصور 📷"}, {"text": "الإعدادات ⚙️"}],
            [{"text": "إنشاء PDF 🖨️"}, {"text": "عن البوت ℹ️"}]
        ],
        "resize_keyboard": True
    }
    
    if pdf_bot.is_admin(user_id, ADMIN_IDS):
        keyboard["keyboard"].append([{"text": "لوحة التحكم 🛠️"}])
    
    # إرسال رسالة الترحيب
    send_message(
        chat_id,
        f"مرحباً {first_name}!\n"
        "بوت تحويل الصور إلى PDF\n\n"
        "✓ أرسل الصور واحدة تلو الأخرى\n"
        "✓ اضغط إنشاء PDF عند الانتهاء\n"
        "✓ يمكنك ضبط الإعدادات أولاً",
        reply_markup=keyboard
    )

def handle_cancel(chat_id, user_id):
    """معالجة أمر الإلغاء"""
    # مسح أي عمليات معلقة
    if user_id in users_data:
        users_data[user_id]["images"] = []
    
    pdf_bot.cleanup_user_files(user_id)
    
    send_message(chat_id, "تم إلغاء العملية الحالية. اضغط /start للبدء من جديد.")

def handle_about(chat_id):
    """عرض معلومات حول البوت"""
    uptime = pdf_bot.get_uptime_string(bot_settings["start_time"])
    
    send_message(
        chat_id,
        "🤖 *بوت تحويل الصور إلى PDF*\n\n"
        "يتيح هذا البوت تحويل صورك إلى ملف PDF بكل سهولة، مع إمكانية ضبط الجودة وإضافة علامة مائية وضغط الملف.\n\n"
        f"📊 *إحصائيات البوت*\n"
        f"• مدة التشغيل: {uptime}\n"
        f"• عدد الملفات المنشأة: {bot_settings['total_pdfs']}\n"
        f"• عدد المستخدمين: {len(users_data)}\n\n"
        "📬 *للاستفسارات والمساعدة*\n"
        "تواصل مع المطور عبر: @dev_contact",
        parse_mode="Markdown"
    )

def handle_settings(chat_id, user_id):
    """عرض قائمة الإعدادات"""
    if user_id not in users_data:
        return handle_start(chat_id, user_id, "المستخدم")
    
    user_settings = users_data[user_id]["settings"]
    
    # إنشاء لوحة مفاتيح الإعدادات
    page_sizes = {"A4": "A4", "A5": "A5", "Letter": "Letter", "Legal": "Legal"}
    orientations = {"portrait": "عمودي", "landscape": "أفقي"}
    
    keyboard = {
        "inline_keyboard": [
            # الصفحة الأولى: الإعدادات الأساسية
            [
                {
                    "text": f"الجودة: {'عالية' if user_settings.get('quality', 'high') == 'high' else 'عادية'}",
                    "callback_data": "quality"
                }
            ],
            [
                {
                    "text": f"العلامة المائية: {'✅' if user_settings.get('watermark', False) else '❌'}",
                    "callback_data": "watermark"
                }
            ],
            [
                {
                    "text": f"ضغط الملف: {'✅' if user_settings.get('compress', False) else '❌'}",
                    "callback_data": "compress"
                }
            ],
            [
                {
                    "text": f"ترقيم الصفحات: {'✅' if user_settings.get('add_page_numbers', False) else '❌'}",
                    "callback_data": "add_page_numbers"
                }
            ],
            [
                {
                    "text": f"حجم الصفحة: {page_sizes.get(user_settings.get('page_size', 'A4'), 'A4')}",
                    "callback_data": "page_size"
                },
                {
                    "text": f"الاتجاه: {orientations.get(user_settings.get('orientation', 'portrait'), 'عمودي')}",
                    "callback_data": "orientation"
                }
            ],
            [
                {
                    "text": "ضبط السطوع والتباين",
                    "callback_data": "adjust_image"
                }
            ],
            [
                {
                    "text": "تغيير نص العلامة المائية",
                    "callback_data": "watermark_text"
                }
            ],
            [
                {
                    "text": "🔄 المزيد من الإعدادات",
                    "callback_data": "settings_page_2"
                }
            ],
            [
                {
                    "text": "حفظ كقالب",
                    "callback_data": "save_template"
                },
                {
                    "text": "تحميل قالب",
                    "callback_data": "load_template"
                }
            ],
            [
                {
                    "text": "العودة للقائمة الرئيسية",
                    "callback_data": "back_to_main"
                }
            ]
        ]
    }
    
    send_message(
        chat_id,
        "📋 *إعدادات PDF*\n\n"
        "اضبط اعدادات ملف PDF حسب تفضيلاتك:",
        reply_markup=keyboard,
        parse_mode="Markdown"
    )

def handle_admin_command(chat_id, user_id):
    """لوحة التحكم للمسؤولين"""
    if not pdf_bot.is_admin(user_id, ADMIN_IDS):
        send_message(chat_id, "ليس لديك صلاحية الوصول إلى لوحة التحكم.")
        return
    
    # إنشاء لوحة مفاتيح المسؤول
    keyboard = {
        "keyboard": [
            [{"text": f"وضع الصيانة: {'✅' if bot_settings['maintenance'] else '❌'}"}],
            [{"text": f"الوضع المجاني: {'✅' if bot_settings['free_mode'] else '❌'}"}],
            [{"text": "إحصائيات البوت"}],
            [{"text": "قائمة المستخدمين"}],
            [{"text": "العودة للقائمة الرئيسية"}]
        ],
        "resize_keyboard": True
    }
    
    send_message(
        chat_id,
        "👨‍💻 *لوحة تحكم المشرف*\n\n"
        f"• وضع الصيانة: {'✅' if bot_settings['maintenance'] else '❌'}\n"
        f"• الوضع المجاني: {'✅' if bot_settings['free_mode'] else '❌'}\n"
        f"• عدد المستخدمين: {len(users_data)}\n"
        f"• إجمالي ملفات PDF: {bot_settings['total_pdfs']}",
        reply_markup=keyboard,
        parse_mode="Markdown"
    )

def handle_photo(message):
    """معالجة الصور الواردة"""
    chat_id = message["chat"]["id"]
    user_id = message["from"]["id"]
    first_name = message["from"]["first_name"]
    
    # تهيئة المستخدم إذا لزم الأمر
    if user_id not in users_data:
        pdf_bot.init_user_data(users_data, user_id, first_name)
    
    # التحقق من حد عدد الصور
    if len(users_data[user_id]["images"]) >= MAX_IMAGES_PER_USER:
        send_message(
            chat_id,
            f"لقد وصلت للحد الأقصى من الصور ({MAX_IMAGES_PER_USER} صورة).\n"
            "يمكنك الآن إنشاء ملف PDF أو إلغاء العملية وبدء مجموعة صور جديدة."
        )
        return
    
    # الحصول على الصورة بأعلى جودة
    photos = message.get("photo", [])
    if not photos:
        return
    
    photo = photos[-1]  # أعلى دقة
    file_id = photo.get("file_id")
    file_info = get_file(file_id)
    
    if not file_info or "file_path" not in file_info:
        send_message(chat_id, "حدث خطأ أثناء معالجة الصورة. يرجى المحاولة مرة أخرى.")
        return
    
    # التحقق من حجم الملف
    file_size = file_info.get("file_size", 0)
    if file_size > MAX_FILE_SIZE_MB * 1024 * 1024:
        send_message(
            chat_id,
            f"حجم الملف كبير جداً. الحد الأقصى المسموح هو {MAX_FILE_SIZE_MB} ميجابايت."
        )
        return
    
    # إنشاء دليل مؤقت
    temp_dir = pdf_bot.ensure_user_temp_dir(user_id)
    img_index = len(users_data[user_id]["images"])
    image_path = os.path.join(temp_dir, f"image_{img_index}.jpg")
    
    # تنزيل الصورة
    download_file(file_info["file_path"], image_path)
    users_data[user_id]["images"].append(image_path)
    
    # تحديث آخر نشاط
    users_data[user_id]["last_activity"] = pdf_bot.format_datetime(datetime.now())
    
    # إرسال رسالة تأكيد
    send_message(
        chat_id,
        f"تم استلام الصورة ({len(users_data[user_id]['images'])}/{MAX_IMAGES_PER_USER}).\n"
        "يمكنك إرسال المزيد أو الضغط على 'إنشاء PDF' عند الانتهاء."
    )

def handle_text_button(chat_id, user_id, text):
    """معالجة الأزرار النصية"""
    # تحديث آخر نشاط
    if user_id in users_data:
        users_data[user_id]["last_activity"] = pdf_bot.format_datetime(datetime.now())
    
    # معالجة الأزرار النصية
    if text == "إرسال الصور 📷":
        send_message(
            chat_id,
            "أرسل الصور التي ترغب في تحويلها إلى PDF.\n"
            f"يمكنك إرسال حتى {MAX_IMAGES_PER_USER} صورة."
        )
    
    elif text == "الإعدادات ⚙️":
        handle_settings(chat_id, user_id)
    
    elif text == "إنشاء PDF 🖨️":
        handle_create_pdf(chat_id, user_id)
    
    elif text == "عن البوت ℹ️":
        handle_about(chat_id)
    
    elif text == "لوحة التحكم 🛠️" and pdf_bot.is_admin(user_id, ADMIN_IDS):
        handle_admin_command(chat_id, user_id)
    
    # أزرار لوحة التحكم
    elif "وضع الصيانة" in text and pdf_bot.is_admin(user_id, ADMIN_IDS):
        bot_settings["maintenance"] = not bot_settings["maintenance"]
        status = "✅ تفعيل" if bot_settings["maintenance"] else "❌ تعطيل"
        send_message(chat_id, f"تم {status} وضع الصيانة")
        handle_admin_command(chat_id, user_id)
    
    elif "الوضع المجاني" in text and pdf_bot.is_admin(user_id, ADMIN_IDS):
        bot_settings["free_mode"] = not bot_settings["free_mode"]
        status = "✅ تفعيل" if bot_settings["free_mode"] else "❌ تعطيل"
        send_message(chat_id, f"تم {status} الوضع المجاني")
        handle_admin_command(chat_id, user_id)
    
    elif text == "إحصائيات البوت" and pdf_bot.is_admin(user_id, ADMIN_IDS):
        active_users = 0
        inactive_users = 0
        total_pdfs = bot_settings["total_pdfs"]
        
        for user in users_data.values():
            if "last_activity" in user:
                last = datetime.strptime(user["last_activity"], "%Y-%m-%d %H:%M:%S")
                delta = datetime.now() - last
                if delta.days < 7:  # نشط خلال الأسبوع الماضي
                    active_users += 1
                else:
                    inactive_users += 1
                    
        send_message(
            chat_id,
            "📊 *إحصائيات البوت*\n\n"
            f"• مدة التشغيل: {pdf_bot.get_uptime_string(bot_settings['start_time'])}\n"
            f"• إجمالي المستخدمين: {len(users_data)}\n"
            f"• المستخدمون النشطون: {active_users}\n"
            f"• المستخدمون غير النشطين: {inactive_users}\n"
            f"• إجمالي ملفات PDF: {total_pdfs}",
            parse_mode="Markdown"
        )
    
    elif text == "قائمة المستخدمين" and pdf_bot.is_admin(user_id, ADMIN_IDS):
        if not users_data:
            send_message(chat_id, "لا يوجد مستخدمون حتى الآن.")
            return
        
        user_list = "👥 *قائمة المستخدمين*\n\n"
        for uid, udata in list(users_data.items())[:20]:  # أول 20 مستخدمًا فقط
            name = udata.get("name", "غير معروف")
            pdf_count = udata.get("pdf_count", 0)
            last_activity = udata.get("last_activity", "غير متوفر")
            user_list += f"• {name} (ID: {uid})\n"
            user_list += f"  PDF: {pdf_count} | آخر نشاط: {last_activity}\n"
        
        if len(users_data) > 20:
            user_list += f"\n... و{len(users_data) - 20} آخرين"
        
        send_message(chat_id, user_list, parse_mode="Markdown")
    
    elif text == "العودة للقائمة الرئيسية":
        # العودة إلى القائمة الرئيسية
        keyboard = {
            "keyboard": [
                [{"text": "إرسال الصور 📷"}, {"text": "الإعدادات ⚙️"}],
                [{"text": "إنشاء PDF 🖨️"}, {"text": "عن البوت ℹ️"}]
            ],
            "resize_keyboard": True
        }
        
        if pdf_bot.is_admin(user_id, ADMIN_IDS):
            keyboard["keyboard"].append([{"text": "لوحة التحكم 🛠️"}])
        
        send_message(
            chat_id,
            "تم العودة للقائمة الرئيسية. يمكنك الآن إرسال الصور أو تغيير الإعدادات.",
            reply_markup=keyboard
        )
    
    else:
        send_message(chat_id, "لم أفهم هذا الأمر. يرجى استخدام الأزرار أو الأوامر المدعومة.")

def handle_callback_query(callback_query):
    """معالجة استدعاءات الأزرار"""
    query_id = callback_query.get("id")
    data = callback_query.get("data")
    chat_id = callback_query["message"]["chat"]["id"]
    user_id = callback_query["from"]["id"]
    message_id = callback_query["message"]["message_id"]
    
    # الميزات المتقدمة الجديدة
    if data == "translate_text":
        # ترجمة النص المستخرج
        if "last_extracted_text" in users_data.get(user_id, {}):
            text = users_data[user_id]["last_extracted_text"]
            target_lang = users_data[user_id]["settings"].get("language", "ar")
            translated_text = pdf_bot.translate_document_text(text, target_lang)
            
            send_message(
                chat_id,
                f"*النص المترجم:*\n\n{translated_text}",
                parse_mode="Markdown"
            )
        else:
            requests.post(
                f"{API_URL}/answerCallbackQuery",
                json={
                    "callback_query_id": query_id,
                    "text": "لا يوجد نص مستخرج للترجمة!",
                    "show_alert": True
                }
            )
    
    elif data == "convert_to_docx":
        # تحويل PDF إلى Word
        if "files" in users_data[user_id] and "last_pdf" in users_data[user_id]["files"]:
            pdf_path = users_data[user_id]["files"]["last_pdf"]
            
            # إخبار المستخدم أن البوت يعمل على التحويل
            send_message(
                chat_id,
                "جاري تحويل PDF إلى ملف Word... يرجى الانتظار"
            )
            
            # معالجة التحويل
            try:
                temp_dir = pdf_bot.ensure_user_temp_dir(user_id)
                output_path = os.path.join(temp_dir, "converted_doc.docx")
                
                # تحويل PDF إلى Word
                docx_path = pdf_bot.convert_pdf_to_docx(pdf_path, output_path)
                
                if docx_path and os.path.exists(docx_path):
                    # إرسال المستند
                    send_document(
                        chat_id,
                        docx_path,
                        caption="تم تحويل PDF إلى ملف Word"
                    )
                    
                    # تسجيل النشاط
                    pdf_bot.log_user_activity(users_data, user_id, "convert_pdf_to_docx")
                else:
                    send_message(
                        chat_id,
                        "حدث خطأ أثناء التحويل، يرجى المحاولة لاحقاً."
                    )
            except Exception as e:
                logger.error(f"خطأ في تحويل PDF إلى Word: {e}")
                send_message(
                    chat_id,
                    "حدث خطأ أثناء التحويل، يرجى المحاولة لاحقاً."
                )
        else:
            requests.post(
                f"{API_URL}/answerCallbackQuery",
                json={
                    "callback_query_id": query_id,
                    "text": "لا يوجد ملف PDF متاح للتحويل!",
                    "show_alert": True
                }
            )
    
    elif data == "business_card":
        # طلب معلومات بطاقة العمل
        keyboard = {
            "inline_keyboard": [
                [
                    {
                        "text": "إلغاء",
                        "callback_data": "cancel_business_card"
                    }
                ]
            ]
        }
        
        # وضع علامة على أن المستخدم في وضع إنشاء بطاقة عمل
        users_data[user_id]["creating_business_card"] = {
            "stage": "name",
            "data": {}
        }
        
        requests.post(
            f"{API_URL}/editMessageText",
            json={
                "chat_id": chat_id,
                "message_id": message_id,
                "text": "🪪 *إنشاء بطاقة عمل*\n\n"
                      "الرجاء إدخال الاسم:",
                "reply_markup": keyboard,
                "parse_mode": "Markdown"
            }
        )
        return
    
    elif data == "protect_last_pdf":
        # طلب كلمة مرور لحماية آخر ملف PDF
        if "files" in users_data[user_id] and "last_pdf" in users_data[user_id]["files"]:
            keyboard = {
                "inline_keyboard": [
                    [
                        {
                            "text": "إلغاء",
                            "callback_data": "cancel_protect_pdf"
                        }
                    ]
                ]
            }
            
            # وضع علامة على أن المستخدم ينتظر إدخال كلمة المرور
            users_data[user_id]["awaiting_pdf_password"] = True
            
            requests.post(
                f"{API_URL}/editMessageText",
                json={
                    "chat_id": chat_id,
                    "message_id": message_id,
                    "text": "🔒 *حماية ملف PDF*\n\n"
                          "الرجاء إدخال كلمة المرور لحماية الملف:",
                    "reply_markup": keyboard,
                    "parse_mode": "Markdown"
                }
            )
            return
        else:
            requests.post(
                f"{API_URL}/answerCallbackQuery",
                json={
                    "callback_query_id": query_id,
                    "text": "لا يوجد ملف PDF متاح للحماية!",
                    "show_alert": True
                }
            )
            
    elif data == "ocr_last_pdf":
        # استخراج النص من آخر ملف PDF
        if "files" in users_data[user_id] and "last_pdf" in users_data[user_id]["files"]:
            # تحديد لغة OCR
            lang = users_data[user_id]["settings"].get("language", "ar")
            ocr_lang = "ara+eng"  # الافتراضي: العربية والإنجليزية
            
            # تنفيذ عملية OCR
            handle_ocr_request(chat_id, user_id)
        else:
            requests.post(
                f"{API_URL}/answerCallbackQuery",
                json={
                    "callback_query_id": query_id,
                    "text": "لا يوجد ملف PDF متاح لاستخراج النص!",
                    "show_alert": True
                }
            )
    
    if query_id:
        requests.post(f"{API_URL}/answerCallbackQuery", json={"callback_query_id": query_id})
    
    if user_id not in users_data:
        handle_start(chat_id, user_id, "المستخدم")
        return
    
    user_settings = users_data[user_id]["settings"]
    
    # معالجة خيارات الإعدادات المختلفة
    if data == "quality":
        # تبديل إعداد الجودة
        user_settings["quality"] = "normal" if user_settings["quality"] == "high" else "high"
        # تحديث الإعدادات وإظهار صفحة الإعدادات الرئيسية
        handle_settings_update(chat_id, message_id, user_id)
    
    elif data == "watermark":
        # تبديل إعداد العلامة المائية
        user_settings["watermark"] = not user_settings.get("watermark", False)
        # تحديث الإعدادات وإظهار صفحة الإعدادات الرئيسية
        handle_settings_update(chat_id, message_id, user_id)
    
    elif data == "compress":
        # تبديل إعداد الضغط
        user_settings["compress"] = not user_settings.get("compress", False)
        # تحديث الإعدادات وإظهار صفحة الإعدادات الرئيسية
        handle_settings_update(chat_id, message_id, user_id)
    
    elif data == "add_page_numbers":
        # تبديل إعداد ترقيم الصفحات
        user_settings["add_page_numbers"] = not user_settings.get("add_page_numbers", False)
        # تحديث الإعدادات وإظهار صفحة الإعدادات الرئيسية
        handle_settings_update(chat_id, message_id, user_id)
    
    elif data == "page_size":
        # تغيير حجم الصفحة
        page_sizes = ["A4", "A5", "Letter", "Legal"]
        current_index = page_sizes.index(user_settings.get("page_size", "A4")) if user_settings.get("page_size", "A4") in page_sizes else 0
        next_index = (current_index + 1) % len(page_sizes)
        user_settings["page_size"] = page_sizes[next_index]
        # تحديث الإعدادات وإظهار صفحة الإعدادات الرئيسية
        handle_settings_update(chat_id, message_id, user_id)
    
    elif data == "orientation":
        # تغيير اتجاه الصفحة
        user_settings["orientation"] = "landscape" if user_settings.get("orientation", "portrait") == "portrait" else "portrait"
        # تحديث الإعدادات وإظهار صفحة الإعدادات الرئيسية
        handle_settings_update(chat_id, message_id, user_id)
    
    elif data == "adjust_image":
        # إظهار إعدادات ضبط الصورة (السطوع والتباين)
        keyboard = {
            "inline_keyboard": [
                [
                    {
                        "text": "السطوع -",
                        "callback_data": "brightness_down"
                    },
                    {
                        "text": f"{user_settings.get('brightness', 1.0):.1f}",
                        "callback_data": "brightness_info"
                    },
                    {
                        "text": "السطوع +",
                        "callback_data": "brightness_up"
                    }
                ],
                [
                    {
                        "text": "التباين -",
                        "callback_data": "contrast_down"
                    },
                    {
                        "text": f"{user_settings.get('contrast', 1.0):.1f}",
                        "callback_data": "contrast_info"
                    },
                    {
                        "text": "التباين +",
                        "callback_data": "contrast_up"
                    }
                ],
                [
                    {
                        "text": "إعادة تعيين",
                        "callback_data": "reset_adjustments"
                    }
                ],
                [
                    {
                        "text": "العودة للإعدادات",
                        "callback_data": "back_to_settings"
                    }
                ]
            ]
        }
        
        requests.post(
            f"{API_URL}/editMessageText",
            json={
                "chat_id": chat_id,
                "message_id": message_id,
                "text": "🖼️ *ضبط الصورة*\n\n"
                      "اضبط السطوع والتباين للصور:\n"
                      f"• السطوع: {user_settings.get('brightness', 1.0):.1f}\n"
                      f"• التباين: {user_settings.get('contrast', 1.0):.1f}",
                "reply_markup": keyboard,
                "parse_mode": "Markdown"
            }
        )
        return
    
    elif data == "brightness_up":
        # زيادة السطوع
        brightness = user_settings.get("brightness", 1.0)
        brightness = min(2.0, brightness + 0.1)
        user_settings["brightness"] = round(brightness, 1)
        # إعادة عرض إعدادات ضبط الصورة
        handle_callback_query({"id": query_id, "data": "adjust_image", "message": callback_query["message"], "from": callback_query["from"]})
    
    elif data == "brightness_down":
        # تخفيض السطوع
        brightness = user_settings.get("brightness", 1.0)
        brightness = max(0.5, brightness - 0.1)
        user_settings["brightness"] = round(brightness, 1)
        # إعادة عرض إعدادات ضبط الصورة
        handle_callback_query({"id": query_id, "data": "adjust_image", "message": callback_query["message"], "from": callback_query["from"]})
    
    elif data == "contrast_up":
        # زيادة التباين
        contrast = user_settings.get("contrast", 1.0)
        contrast = min(2.0, contrast + 0.1)
        user_settings["contrast"] = round(contrast, 1)
        # إعادة عرض إعدادات ضبط الصورة
        handle_callback_query({"id": query_id, "data": "adjust_image", "message": callback_query["message"], "from": callback_query["from"]})
    
    elif data == "contrast_down":
        # تخفيض التباين
        contrast = user_settings.get("contrast", 1.0)
        contrast = max(0.5, contrast - 0.1)
        user_settings["contrast"] = round(contrast, 1)
        # إعادة عرض إعدادات ضبط الصورة
        handle_callback_query({"id": query_id, "data": "adjust_image", "message": callback_query["message"], "from": callback_query["from"]})
    
    elif data == "reset_adjustments":
        # إعادة تعيين إعدادات السطوع والتباين
        user_settings["brightness"] = 1.0
        user_settings["contrast"] = 1.0
        # إعادة عرض إعدادات ضبط الصورة
        handle_callback_query({"id": query_id, "data": "adjust_image", "message": callback_query["message"], "from": callback_query["from"]})
    
    elif data == "back_to_settings":
        # العودة لقائمة الإعدادات الرئيسية
        handle_settings_update(chat_id, message_id, user_id)
    
    elif data == "settings_page_2":
        # الانتقال إلى صفحة الإعدادات الثانية (المتقدمة)
        show_advanced_settings(chat_id, message_id, user_id)
    
    elif data == "settings_page_1":
        # العودة إلى صفحة الإعدادات الأولى (الأساسية)
        handle_settings_update(chat_id, message_id, user_id)
    
    elif data == "save_template":
        # طلب اسم القالب
        keyboard = {
            "inline_keyboard": [
                [
                    {
                        "text": "إلغاء",
                        "callback_data": "cancel_template_name"
                    }
                ]
            ]
        }
        
        requests.post(
            f"{API_URL}/editMessageText",
            json={
                "chat_id": chat_id,
                "message_id": message_id,
                "text": "أرسل اسماً للقالب الجديد:",
                "reply_markup": keyboard
            }
        )
        
        # وضع علامة على أن المستخدم ينتظر إدخال اسم القالب
        users_data[user_id]["awaiting_template_name"] = True
        return
    
    elif data == "load_template":
        # عرض قائمة بالقوالب المحفوظة
        templates = pdf_bot.get_user_templates(users_data, user_id)
        
        if not templates:
            requests.post(
                f"{API_URL}/answerCallbackQuery",
                json={
                    "callback_query_id": query_id,
                    "text": "ليس لديك أي قوالب محفوظة بعد!",
                    "show_alert": True
                }
            )
            return
        
        # إنشاء أزرار للقوالب
        inline_buttons = []
        for template_name in templates:
            inline_buttons.append([{"text": template_name, "callback_data": f"template:{template_name}"}])
        
        # إضافة زر العودة
        inline_buttons.append([{"text": "العودة للإعدادات", "callback_data": "back_to_settings"}])
        
        keyboard = {
            "inline_keyboard": inline_buttons
        }
        
        requests.post(
            f"{API_URL}/editMessageText",
            json={
                "chat_id": chat_id,
                "message_id": message_id,
                "text": "📑 *القوالب المحفوظة*\n\n"
                      "اختر قالباً لتحميله:",
                "reply_markup": keyboard,
                "parse_mode": "Markdown"
            }
        )
        return
    
    elif data.startswith("template:"):
        # تحميل قالب محفوظ
        template_name = data.split(":", 1)[1]
        templates = pdf_bot.get_user_templates(users_data, user_id)
        
        if template_name in templates:
            # نسخ إعدادات القالب
            template_settings = templates[template_name]
            for key, value in template_settings.items():
                if key != "created_at":  # تجاهل حقل تاريخ الإنشاء
                    user_settings[key] = value
            
            requests.post(
                f"{API_URL}/answerCallbackQuery",
                json={
                    "callback_query_id": query_id,
                    "text": f"تم تحميل القالب '{template_name}' بنجاح",
                    "show_alert": False
                }
            )
            
            # تحديث الإعدادات وإظهار صفحة الإعدادات الرئيسية
            handle_settings_update(chat_id, message_id, user_id)
        else:
            requests.post(
                f"{API_URL}/answerCallbackQuery",
                json={
                    "callback_query_id": query_id,
                    "text": "لم يتم العثور على القالب!",
                    "show_alert": True
                }
            )
    
    elif data == "cancel_template_name":
        # إلغاء طلب اسم القالب
        if "awaiting_template_name" in users_data[user_id]:
            del users_data[user_id]["awaiting_template_name"]
        
        # العودة لقائمة الإعدادات الرئيسية
        handle_settings_update(chat_id, message_id, user_id)
    
    elif data == "watermark_text":
        # طلب نص العلامة المائية
        keyboard = {
            "inline_keyboard": [
                [
                    {
                        "text": "إلغاء",
                        "callback_data": "cancel_watermark_text"
                    }
                ]
            ]
        }
        
        requests.post(
            f"{API_URL}/editMessageText",
            json={
                "chat_id": chat_id,
                "message_id": message_id,
                "text": "أرسل نص العلامة المائية الجديدة:",
                "reply_markup": keyboard
            }
        )
        
        # وضع علامة على أن المستخدم ينتظر إدخال نص العلامة المائية
        users_data[user_id]["awaiting_watermark_text"] = True
        return
    
    elif data == "cancel_watermark_text":
        # إلغاء طلب نص العلامة المائية
        if "awaiting_watermark_text" in users_data[user_id]:
            del users_data[user_id]["awaiting_watermark_text"]
        
        # العودة لقائمة الإعدادات الرئيسية
        handle_settings_update(chat_id, message_id, user_id)
    
    elif data == "back_to_main":
        # العودة إلى القائمة الرئيسية
        keyboard = {
            "keyboard": [
                [{"text": "إرسال الصور 📷"}, {"text": "الإعدادات ⚙️"}],
                [{"text": "إنشاء PDF 🖨️"}, {"text": "عن البوت ℹ️"}]
            ],
            "resize_keyboard": True
        }
        
        if pdf_bot.is_admin(user_id, ADMIN_IDS):
            keyboard["keyboard"].append([{"text": "لوحة التحكم 🛠️"}])
        
        requests.post(
            f"{API_URL}/editMessageText",
            json={
                "chat_id": chat_id,
                "message_id": message_id,
                "text": "تم العودة للقائمة الرئيسية. يمكنك الآن إرسال الصور أو تغيير الإعدادات."
            }
        )
        
        send_message(
            chat_id,
            "القائمة الرئيسية",
            reply_markup=keyboard
        )
        
        return

def handle_settings_update(chat_id, message_id, user_id):
    """تحديث رسالة الإعدادات بالقيم الجديدة"""
    if user_id not in users_data:
        return
    
    user_settings = users_data[user_id]["settings"]
    page_sizes = {"A4": "A4", "A5": "A5", "Letter": "Letter", "Legal": "Legal"}
    orientations = {"portrait": "عمودي", "landscape": "أفقي"}
    
    # إنشاء لوحة مفاتيح الإعدادات المحدثة
    keyboard = {
        "inline_keyboard": [
            [
                {
                    "text": f"الجودة: {'عالية' if user_settings.get('quality', 'high') == 'high' else 'عادية'}",
                    "callback_data": "quality"
                }
            ],
            [
                {
                    "text": f"العلامة المائية: {'✅' if user_settings.get('watermark', False) else '❌'}",
                    "callback_data": "watermark"
                }
            ],
            [
                {
                    "text": f"ضغط الملف: {'✅' if user_settings.get('compress', False) else '❌'}",
                    "callback_data": "compress"
                }
            ],
            [
                {
                    "text": f"ترقيم الصفحات: {'✅' if user_settings.get('add_page_numbers', False) else '❌'}",
                    "callback_data": "add_page_numbers"
                }
            ],
            [
                {
                    "text": f"حجم الصفحة: {page_sizes.get(user_settings.get('page_size', 'A4'), 'A4')}",
                    "callback_data": "page_size"
                },
                {
                    "text": f"الاتجاه: {orientations.get(user_settings.get('orientation', 'portrait'), 'عمودي')}",
                    "callback_data": "orientation"
                }
            ],
            [
                {
                    "text": "ضبط السطوع والتباين",
                    "callback_data": "adjust_image"
                }
            ],
            [
                {
                    "text": "تغيير نص العلامة المائية",
                    "callback_data": "watermark_text"
                }
            ],
            [
                {
                    "text": "🔄 المزيد من الإعدادات",
                    "callback_data": "settings_page_2"
                }
            ],
            [
                {
                    "text": "حفظ كقالب",
                    "callback_data": "save_template"
                },
                {
                    "text": "تحميل قالب",
                    "callback_data": "load_template"
                }
            ],
            [
                {
                    "text": "العودة للقائمة الرئيسية",
                    "callback_data": "back_to_main"
                }
            ]
        ]
    }
    
    requests.post(
        f"{API_URL}/editMessageText",
        json={
            "chat_id": chat_id,
            "message_id": message_id,
            "text": "📋 *إعدادات PDF*\n\n"
                  "اضبط اعدادات ملف PDF حسب تفضيلاتك:",
            "reply_markup": keyboard,
            "parse_mode": "Markdown"
        }
    )

def show_advanced_settings(chat_id, message_id, user_id):
    """عرض الإعدادات المتقدمة (الصفحة الثانية)"""
    if user_id not in users_data:
        return
    
    user_settings = users_data[user_id]["settings"]
    
    # إنشاء قائمة الإعدادات المتقدمة
    keyboard = {
        "inline_keyboard": [
            [
                {
                    "text": "OCR - استخراج النص",
                    "callback_data": "ocr_settings"
                }
            ],
            [
                {
                    "text": "دمج ملفات PDF",
                    "callback_data": "merge_pdfs"
                }
            ],
            [
                {
                    "text": "تقسيم ملف PDF",
                    "callback_data": "split_pdf"
                }
            ],
            [
                {
                    "text": "حماية PDF بكلمة مرور",
                    "callback_data": "protect_pdf"
                }
            ],
            [
                {
                    "text": "تحويل PDF إلى Word",
                    "callback_data": "convert_to_docx"
                }
            ],
            [
                {
                    "text": "إنشاء بطاقة عمل",
                    "callback_data": "business_card"
                }
            ],
            [
                {
                    "text": f"اللغة: {user_settings.get('language', 'ar')}",
                    "callback_data": "change_language"
                }
            ],
            [
                {
                    "text": "📄 العودة للإعدادات الأساسية",
                    "callback_data": "settings_page_1"
                }
            ],
            [
                {
                    "text": "العودة للقائمة الرئيسية",
                    "callback_data": "back_to_main"
                }
            ]
        ]
    }
    
    requests.post(
        f"{API_URL}/editMessageText",
        json={
            "chat_id": chat_id,
            "message_id": message_id,
            "text": "🔧 *الإعدادات المتقدمة*\n\n"
                  "اختر من الوظائف المتقدمة:",
            "reply_markup": keyboard,
            "parse_mode": "Markdown"
        }
    )

def handle_watermark_text(message):
    """معالجة إدخال نص العلامة المائية"""
    chat_id = message["chat"]["id"]
    user_id = message["from"]["id"]
    new_text = message.get("text", "").strip()
    
    if user_id not in users_data or not users_data[user_id].get("awaiting_watermark_text"):
        return False  # ليس في حالة انتظار نص العلامة المائية
    
    # إنهاء حالة انتظار نص العلامة المائية
    del users_data[user_id]["awaiting_watermark_text"]
    
    if len(new_text) > 50:
        send_message(
            chat_id,
            "النص طويل جداً. الرجاء إدخال نص لا يتجاوز 50 حرفاً."
        )
    else:
        # تعيين نص العلامة المائية لهذا المستخدم
        users_data[user_id]["custom_watermark_text"] = new_text
        send_message(chat_id, f"تم تعيين نص العلامة المائية: \"{new_text}\"")
    
    # العودة إلى قائمة الإعدادات
    handle_settings(chat_id, user_id)
    return True

def update_progress_message(chat_id, message_id, current, total, stage=None):
    """تحديث رسالة التقدم"""
    # حساب النسبة المئوية
    percent = min(100, int((current / total) * 100))
    
    # إنشاء شريط التقدم
    bar_length = 20
    filled_length = int(bar_length * current / total)
    bar = '▰' * filled_length + '▱' * (bar_length - filled_length)
    
    # تحديد النص حسب المرحلة
    if stage == "compress":
        stage_text = "جاري ضغط الملف"
    elif stage == "watermark":
        stage_text = "جاري إضافة العلامة المائية"
    elif stage == "page_numbers":
        stage_text = "جاري إضافة أرقام الصفحات"
    elif stage == "final_processing":
        stage_text = "جاري إنشاء ملف PDF النهائي"
    else:
        stage_text = "جاري معالجة الصور"
    
    # تحديث الرسالة
    text = f"⏳ *إنشاء ملف PDF*\n\n" \
           f"المرحلة: *{stage_text}*\n" \
           f"التقدم: *{current}/{total}* صورة\n" \
           f"{bar} *{percent}%*"
    
    params = {
        "chat_id": chat_id,
        "message_id": message_id,
        "text": text,
        "parse_mode": "Markdown"
    }
    
    try:
        requests.post(f"{API_URL}/editMessageText", json=params)
    except Exception as e:
        logger.error(f"خطأ في تحديث رسالة التقدم: {e}")

def handle_create_pdf(chat_id, user_id):
    """إنشاء PDF من الصور المجمعة"""
    # التحقق من وجود صور
    if user_id not in users_data or not users_data[user_id]["images"]:
        send_message(chat_id, "لم تقم بإرسال أي صور بعد! أرسل بعض الصور أولاً.")
        return
    
    # إظهار مؤشر كتابة للإشارة إلى المعالجة
    send_chat_action(chat_id, "typing")
    
    try:
        # إنشاء رسالة تقدم
        progress_message = send_message(
            chat_id,
            f"⏳ *إنشاء ملف PDF*\n\n"
            f"جاري تجهيز {len(users_data[user_id]['images'])} صورة...\n"
            f"▱▱▱▱▱▱▱▱▱▱▱▱▱▱▱▱▱▱▱▱ *0%*",
            parse_mode="Markdown"
        )
        
        # الحصول على معرف الرسالة للتحديثات اللاحقة
        if progress_message and progress_message.get("ok", False):
            message_id = progress_message["result"]["message_id"]
        else:
            # إذا فشل إنشاء رسالة التقدم، استخدم الطريقة القديمة
            send_message(
                chat_id,
                f"جاري إنشاء ملف PDF من {len(users_data[user_id]['images'])} صورة...\n"
                "يرجى الانتظار"
            )
            message_id = None
        
        # إنشاء دليل مؤقت
        temp_dir = pdf_bot.ensure_user_temp_dir(user_id)
        pdf_path = os.path.join(temp_dir, "output.pdf")
        
        # استخراج جميع الإعدادات من المستخدم
        settings = users_data[user_id]["settings"]
        quality = settings.get("quality", "high")
        watermark = settings.get("watermark", False)
        compress = settings.get("compress", False)
        page_size = settings.get("page_size", "A4")
        orientation = settings.get("orientation", "portrait")
        add_page_numbers = settings.get("add_page_numbers", False)
        brightness = settings.get("brightness", 1.0)
        contrast = settings.get("contrast", 1.0)
        
        # استخدام النص المخصص للعلامة المائية إذا كان موجوداً
        watermark_text = bot_settings.get("watermark_text", "Created by PDF Bot")
        if watermark and "custom_watermark_text" in users_data[user_id]:
            watermark_text = users_data[user_id]["custom_watermark_text"]
        
        # تحديد موضع العلامة المائية (الافتراضي: أسفل اليمين)
        watermark_position = settings.get("watermark_position", "bottom-right")
        
        # تحضير للمعالجة التدريجية وإظهار التقدم
        images = []
        total_images = len(users_data[user_id]["images"])
        
        # معالجة كل صورة مع تحديث التقدم
        for index, img_path in enumerate(users_data[user_id]["images"]):
            try:
                # تحديث التقدم
                if message_id:
                    update_progress_message(chat_id, message_id, index + 1, total_images)
                
                # معالجة الصورة
                img = pdf_bot.enhance_image(img_path, quality, brightness, contrast)
                images.append(img)
                
                # إضافة تأخير قصير بين الصور لعرض التقدم للمستخدم
                time.sleep(0.2)
            except Exception as e:
                logger.error(f"خطأ في معالجة الصورة {img_path}: {e}")
        
        # إنشاء PDF
        if message_id:
            update_progress_message(chat_id, message_id, total_images, total_images, 
                                   stage="watermark" if watermark else "page_numbers" if add_page_numbers else "compress" if compress else None)
        
        # تحديث رسالة التقدم قبل الإنشاء النهائي
        if message_id:
            update_progress_message(chat_id, message_id, total_images, total_images, 
                                   stage="final_processing")
        
        # إنشاء PDF
        pdf_path = pdf_bot.create_pdf(
            users_data[user_id]["images"],
            pdf_path,
            quality=quality,
            add_watermark=watermark,
            watermark_text=watermark_text,
            watermark_position=watermark_position,
            compress=compress,
            page_size=page_size,
            orientation=orientation,
            add_page_numbers=add_page_numbers,
            brightness=brightness,
            contrast=contrast,
            processed_images=images  # تمرير الصور المعالجة لتحسين الأداء
        )
        
        # تسجيل نشاط المستخدم
        pdf_bot.log_user_activity(users_data, user_id, "create_pdf", {
            "images_count": len(users_data[user_id]["images"]),
            "quality": quality,
            "page_size": page_size,
            "orientation": orientation
        })
        
        # إرسال الملف الناتج
        response = send_document(
            chat_id,
            pdf_path,
            caption=f"ملف PDF الخاص بك ({len(users_data[user_id]['images'])} صورة)"
        )
        
        # تحديث إحصائيات المستخدم
        users_data[user_id]["pdf_count"] = users_data[user_id].get("pdf_count", 0) + 1
        users_data[user_id]["last_activity"] = pdf_bot.format_datetime(datetime.now())
        bot_settings["total_pdfs"] += 1
        
        # عرض الخيارات المتقدمة بعد إنشاء PDF
        if response and response.get("ok", False):
            keyboard = {
                "inline_keyboard": [
                    [
                        {
                            "text": "استخراج النص (OCR)",
                            "callback_data": "ocr_last_pdf"
                        }
                    ],
                    [
                        {
                            "text": "حماية الملف بكلمة مرور",
                            "callback_data": "protect_last_pdf"
                        }
                    ],
                    [
                        {
                            "text": "حفظ الإعدادات كقالب",
                            "callback_data": "save_template"
                        }
                    ]
                ]
            }
            
            send_message(
                chat_id,
                "🔍 *خيارات متقدمة*\n\n"
                "هل ترغب بمعالجة ملف PDF المنشأ؟",
                reply_markup=keyboard,
                parse_mode="Markdown"
            )
        
        # حفظ بيانات المستخدمين كل 5 عمليات
        if bot_settings["total_pdfs"] % 5 == 0:
            save_data()
        
    except Exception as e:
        logger.error(f"خطأ في إنشاء PDF: {e}")
        logger.error(traceback.format_exc())
        send_message(
            chat_id,
            "حدث خطأ أثناء إنشاء الملف، يرجى المحاولة لاحقاً.\n"
            "إذا استمر الخطأ، تواصل مع الدعم."
        )
    finally:
        # تنظيف الملفات المؤقتة وإعادة تعيين قائمة الصور
        # حفظ آخر ملف PDF في سجل المستخدم (للمعالجة اللاحقة المحتملة)
        if os.path.exists(pdf_path):
            if "files" not in users_data[user_id]:
                users_data[user_id]["files"] = {"pdf": [], "images": []}
            users_data[user_id]["files"]["last_pdf"] = pdf_path
        
        # إعادة تعيين قائمة الصور
        users_data[user_id]["images"] = []

def save_data():
    """حفظ بيانات المستخدمين وإعدادات البوت"""
    try:
        # تحويل معرفات المستخدمين إلى سلاسل نصية
        serializable_users_data = {}
        for user_id, user_data in users_data.items():
            serializable_users_data[str(user_id)] = user_data
        
        with open(USER_DATA_FILE, 'w', encoding='utf-8') as f:
            json.dump(serializable_users_data, f, ensure_ascii=False, indent=2)
        
        # نسخ إعدادات البوت للحفظ
        settings_to_save = bot_settings.copy()
        # تجاهل وقت البدء لأنه لا يمكن تسلسله
        if "start_time" in settings_to_save:
            settings_to_save["start_time"] = pdf_bot.format_datetime(settings_to_save["start_time"])
        
        with open(BOT_SETTINGS_FILE, 'w', encoding='utf-8') as f:
            json.dump(settings_to_save, f, ensure_ascii=False, indent=2)
        
        logger.info("تم حفظ البيانات بنجاح")
    except Exception as e:
        logger.error(f"خطأ في حفظ البيانات: {e}")

def handle_ocr_request(chat_id, user_id, image_path=None, lang="ara+eng"):
    """معالجة طلب OCR"""
    # إظهار مؤشر كتابة للإشارة إلى المعالجة
    send_chat_action(chat_id, "typing")
    
    if not image_path and "files" in users_data[user_id] and "last_pdf" in users_data[user_id]["files"]:
        # إذا لم يتم تحديد صورة وكان آخر ملف PDF متاحاً، استخدم الصفحة الأولى منه
        pdf_path = users_data[user_id]["files"]["last_pdf"]
        temp_dir = pdf_bot.ensure_user_temp_dir(user_id)
        image_path = os.path.join(temp_dir, "last_page.jpg")
        
        try:
            # تحويل الصفحة الأولى من PDF إلى صورة
            from pdf2image import convert_from_path
            pages = convert_from_path(pdf_path, first_page=1, last_page=1)
            if pages:
                pages[0].save(image_path, 'JPEG')
            else:
                send_message(chat_id, "لا يمكن استخراج صفحات من ملف PDF. يرجى المحاولة مرة أخرى بصورة مباشرة.")
                return
        except Exception as e:
            logger.error(f"خطأ في تحويل PDF إلى صورة: {e}")
            send_message(chat_id, "حدث خطأ أثناء معالجة ملف PDF. يرجى إرسال صورة مباشرة للاستخراج.")
            return
    
    if not image_path or not os.path.exists(image_path):
        send_message(chat_id, "لم يتم العثور على صورة للمعالجة. يرجى إرسال صورة أولاً.")
        return
    
    try:
        send_message(chat_id, "جاري استخراج النص من الصورة... يرجى الانتظار")
        
        # استخراج النص
        text = pdf_bot.extract_text_from_image(image_path, lang=lang)
        
        if not text.strip():
            send_message(chat_id, "لم يتم العثور على نص في الصورة. تأكد من وضوح النص وحاول مرة أخرى.")
            return
        
        # إرسال النص المستخرج
        send_message(chat_id, f"*النص المستخرج:*\n\n{text}", parse_mode="Markdown")
        
        # تحديث إحصائيات المستخدم
        users_data[user_id]["ocr_count"] = users_data[user_id].get("ocr_count", 0) + 1
        users_data[user_id]["last_activity"] = pdf_bot.format_datetime(datetime.now())
        bot_settings["total_ocr"] += 1
        
        # تسجيل نشاط المستخدم
        pdf_bot.log_user_activity(users_data, user_id, "ocr", {"lang": lang})
        
    except Exception as e:
        logger.error(f"خطأ في استخراج النص: {e}")
        logger.error(traceback.format_exc())
        send_message(
            chat_id,
            "حدث خطأ أثناء استخراج النص، يرجى المحاولة لاحقاً."
        )

def main_loop():
    """الحلقة الرئيسية للبوت"""
    logger.info("تم بدء تشغيل البوت...")
    offset = None
    
    while True:
        try:
            updates = get_updates(offset)
            
            for update in updates:
                offset = update["update_id"] + 1
                
                # معالجة الرسائل
                if "message" in update:
                    message = update["message"]
                    
                    # التحقق من وجود صورة
                    if "photo" in message:
                        handle_photo(message)
                    
                    # التحقق من وجود نص
                    elif "text" in message:
                        # التحقق من انتظار نص العلامة المائية
                        user_id = message["from"]["id"]
                        if (user_id in users_data and 
                            users_data[user_id].get("awaiting_watermark_text") and 
                            handle_watermark_text(message)):
                            continue
                        
                        # معالجة الأوامر أو النص العادي
                        if message["text"].startswith("/"):
                            handle_command(message)
                        else:
                            handle_text_button(
                                message["chat"]["id"],
                                message["from"]["id"],
                                message["text"]
                            )
                
                # معالجة استدعاءات الأزرار
                elif "callback_query" in update:
                    handle_callback_query(update["callback_query"])
            
            time.sleep(1)
            
        except Exception as e:
            logger.error(f"حدث خطأ: {e}")
            logger.error(traceback.format_exc())
            time.sleep(5)  # الانتظار قبل المحاولة مرة أخرى

if __name__ == "__main__":
    # بدء الحلقة الرئيسية في خيط منفصل
    thread = threading.Thread(target=main_loop)
    thread.daemon = True
    thread.start()
    
    # السماح بالخروج بالضغط على Ctrl+C
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        logger.info("تم إيقاف البوت")