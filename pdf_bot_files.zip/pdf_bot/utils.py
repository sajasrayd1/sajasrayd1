"""
وظائف مساعدة لبوت الـ PDF
"""
import os
import json
import shutil
import logging
import requests
from datetime import datetime, timedelta
from PIL import Image
from PyPDF2 import PdfReader
import random
import string

logger = logging.getLogger(__name__)

# ============ إدارة المستخدمين ============
def is_admin(user_id, admin_ids):
    """التحقق مما إذا كان المستخدم مشرفًا"""
    return user_id in admin_ids

def cleanup_user_files(user_id):
    """حذف الملفات المؤقتة للمستخدم"""
    temp_dir = f"temp_{user_id}"
    if os.path.exists(temp_dir):
        try:
            for file in os.listdir(temp_dir):
                os.remove(os.path.join(temp_dir, file))
            os.rmdir(temp_dir)
            logger.info(f"تم تنظيف ملفات المستخدم {user_id}")
        except Exception as e:
            logger.error(f"خطأ في تنظيف ملفات المستخدم {user_id}: {e}")

def ensure_user_temp_dir(user_id):
    """إنشاء وإرجاع مسار الدليل المؤقت للمستخدم"""
    temp_dir = f"temp_{user_id}"
    os.makedirs(temp_dir, exist_ok=True)
    return temp_dir

def init_user_data(users_data, user_id, name):
    """تهيئة بيانات المستخدم إذا لم تكن موجودة"""
    if user_id not in users_data:
        users_data[user_id] = {
            "name": name,
            "images": [],
            "settings": {
                "quality": "high",
                "watermark": False,
                "compress": False,
                "page_size": "A4",
                "orientation": "portrait",
                "add_page_numbers": False,
                "brightness": 1.0,
                "contrast": 1.0,
                "language": "ar"
            },
            "templates": {},
            "files": {
                "pdf": [],
                "images": []
            },
            "first_seen": format_datetime(datetime.now()),
            "pdf_count": 0,
            "ocr_count": 0,
            "last_activity": format_datetime(datetime.now())
        }
    
    # تحديث آخر نشاط
    users_data[user_id]["last_activity"] = format_datetime(datetime.now())
    
    return users_data[user_id]

def log_user_activity(users_data, user_id, activity_type, details=None):
    """تسجيل نشاط المستخدم"""
    if user_id not in users_data:
        return
    
    if "activity_log" not in users_data[user_id]:
        users_data[user_id]["activity_log"] = []
    
    # تحديد عدد السجلات التي يجب الاحتفاظ بها (آخر 50 نشاط)
    MAX_LOG_ENTRIES = 50
    
    activity = {
        "time": format_datetime(datetime.now()),
        "type": activity_type
    }
    
    if details:
        activity["details"] = details
    
    # إضافة النشاط في بداية القائمة
    users_data[user_id]["activity_log"].insert(0, activity)
    
    # تقليص قائمة النشاطات إذا تجاوزت الحد الأقصى
    if len(users_data[user_id]["activity_log"]) > MAX_LOG_ENTRIES:
        users_data[user_id]["activity_log"] = users_data[user_id]["activity_log"][:MAX_LOG_ENTRIES]

# ============ إدارة القوالب ============
def save_user_template(users_data, user_id, template_name, settings):
    """حفظ إعدادات المستخدم كقالب"""
    if user_id not in users_data:
        return False
    
    if "templates" not in users_data[user_id]:
        users_data[user_id]["templates"] = {}
    
    # نسخ الإعدادات لتجنب تعديل الأصل
    template_settings = settings.copy()
    template_settings["created_at"] = format_datetime(datetime.now())
    
    users_data[user_id]["templates"][template_name] = template_settings
    
    return True

def get_user_templates(users_data, user_id):
    """الحصول على قوالب المستخدم"""
    if (user_id not in users_data or 
        "templates" not in users_data[user_id]):
        return {}
    
    return users_data[user_id]["templates"]

# ============ إدارة الوقت والتاريخ ============
def get_uptime_string(start_time):
    """الحصول على نص مدة التشغيل"""
    uptime = datetime.now() - start_time
    days, remainder = divmod(uptime.total_seconds(), 86400)
    hours, remainder = divmod(remainder, 3600)
    minutes, seconds = divmod(remainder, 60)
    
    return f"{int(days)} يوم, {int(hours)} ساعة, {int(minutes)} دقيقة"

def format_datetime(dt):
    """تنسيق التاريخ والوقت"""
    return dt.strftime("%Y-%m-%d %H:%M:%S")

# ============ إحصائيات الاستخدام ============
def generate_usage_stats(users_data, days=7):
    """توليد إحصائيات استخدام البوت"""
    stats = {
        "total_users": len(users_data),
        "active_users": 0,
        "new_users": 0,
        "total_pdfs": 0,
        "total_ocr": 0,
        "weekly_activity": {
            "pdfs": 0,
            "ocr": 0,
            "users": set()
        }
    }
    
    cutoff_date = datetime.now() - timedelta(days=days)
    cutoff_str = format_datetime(cutoff_date)
    
    for user_id, user_data in users_data.items():
        # إحصائيات عامة
        stats["total_pdfs"] += user_data.get("pdf_count", 0)
        stats["total_ocr"] += user_data.get("ocr_count", 0)
        
        # المستخدمون النشطون خلال الفترة المحددة
        if "last_activity" in user_data:
            last_activity = datetime.strptime(user_data["last_activity"], "%Y-%m-%d %H:%M:%S")
            if last_activity > cutoff_date:
                stats["active_users"] += 1
                stats["weekly_activity"]["users"].add(user_id)
        
        # المستخدمون الجدد
        if "first_seen" in user_data:
            first_seen = datetime.strptime(user_data["first_seen"], "%Y-%m-%d %H:%M:%S")
            if first_seen > cutoff_date:
                stats["new_users"] += 1
        
        # النشاط الأسبوعي
        if "activity_log" in user_data:
            for activity in user_data["activity_log"]:
                if activity["time"] > cutoff_str:
                    if activity["type"] == "create_pdf":
                        stats["weekly_activity"]["pdfs"] += 1
                    elif activity["type"] == "ocr":
                        stats["weekly_activity"]["ocr"] += 1
    
    # تحويل مجموعة المستخدمين إلى عدد
    stats["weekly_activity"]["users"] = len(stats["weekly_activity"]["users"])
    
    return stats

# ============ دعم اللغات ============
def get_language_code(language_name):
    """تحويل اسم اللغة إلى رمز"""
    language_codes = {
        "العربية": "ar",
        "الإنجليزية": "en",
        "الفرنسية": "fr",
        "الإسبانية": "es",
        "الألمانية": "de",
        "الروسية": "ru",
        "التركية": "tr"
    }
    
    return language_codes.get(language_name, "ar")

def translate_text(text, target_lang="ar"):
    """ترجمة النص إلى اللغة المطلوبة (استخدم مكتبة ترجمة مناسبة)"""
    # هذه دالة وهمية - يجب استبدالها بمكتبة ترجمة حقيقية
    # مثل Google Translate API أو Microsoft Translator
    translations = {
        "ar": {
            "PDF Bot": "بوت PDF",
            "Settings": "الإعدادات",
            "Create PDF": "إنشاء PDF",
            "About": "عن البوت",
            "Quality": "الجودة",
            "High": "عالية",
            "Normal": "عادية",
            "Watermark": "علامة مائية",
            "Compress": "ضغط"
        },
        "en": {
            "بوت PDF": "PDF Bot",
            "الإعدادات": "Settings",
            "إنشاء PDF": "Create PDF",
            "عن البوت": "About",
            "الجودة": "Quality",
            "عالية": "High",
            "عادية": "Normal",
            "علامة مائية": "Watermark",
            "ضغط": "Compress"
        }
    }
    
    if target_lang in translations and text in translations[target_lang]:
        return translations[target_lang][text]
    
    return text

# ============ الإشعارات ============
def send_notification(api_url, token, chat_id, message):
    """إرسال إشعار إلى مستخدم معين"""
    try:
        params = {
            "chat_id": chat_id,
            "text": message,
            "parse_mode": "Markdown"
        }
        
        response = requests.post(f"{api_url}/sendMessage", json=params)
        return response.json()
    except Exception as e:
        logger.error(f"خطأ في إرسال الإشعار: {e}")
        return None

# ============ معالجة الملفات ============
def validate_pdf(pdf_path):
    """التحقق من صحة ملف PDF"""
    try:
        reader = PdfReader(pdf_path)
        if len(reader.pages) > 0:
            return True, len(reader.pages)
        else:
            return False, "ملف PDF فارغ"
    except Exception as e:
        return False, str(e)

def resize_image(image_path, max_size=1500):
    """تغيير حجم الصورة إذا كانت كبيرة جداً"""
    try:
        image = Image.open(image_path)
        width, height = image.size
        
        if width > max_size or height > max_size:
            # الحفاظ على النسبة
            if width > height:
                new_width = max_size
                new_height = int(height * (max_size / width))
            else:
                new_height = max_size
                new_width = int(width * (max_size / height))
            
            resized_image = image.resize((new_width, new_height), Image.LANCZOS)
            resized_image.save(image_path)
            logger.info(f"تم تغيير حجم الصورة من {width}x{height} إلى {new_width}x{new_height}")
    
    except Exception as e:
        logger.error(f"خطأ في تغيير حجم الصورة: {e}")

def get_document_info(file_path):
    """الحصول على معلومات حول المستند"""
    file_ext = os.path.splitext(file_path)[1].lower()
    file_info = {
        "file_name": os.path.basename(file_path),
        "size": os.path.getsize(file_path),
        "type": file_ext,
        "last_modified": format_datetime(datetime.fromtimestamp(os.path.getmtime(file_path)))
    }
    
    try:
        if file_ext == ".pdf":
            # معلومات PDF
            reader = PdfReader(file_path)
            file_info["pages"] = len(reader.pages)
            file_info["metadata"] = reader.metadata if reader.metadata else {}
            
        elif file_ext in [".jpg", ".jpeg", ".png", ".bmp", ".tiff", ".gif"]:
            # معلومات الصورة
            image = Image.open(file_path)
            file_info["dimensions"] = f"{image.width}x{image.height}"
            file_info["format"] = image.format
            file_info["mode"] = image.mode
    
    except Exception as e:
        logger.error(f"خطأ في الحصول على معلومات المستند: {e}")
    
    return file_info