"""
تطبيق فلاسك الرئيسي لواجهة ويب PDF Bot
"""
import os
import logging
from datetime import datetime
from flask import Flask, render_template, send_file
import zipfile
import os
import io
from flask import jsonify, request, redirect, url_for, flash, session, Response
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase
from werkzeug.middleware.proxy_fix import ProxyFix

# إعداد التسجيل
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('web_app.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# إنشاء تطبيق فلاسك
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "pdf_bot_secret_key")

# إعداد قاعدة البيانات
database_url = os.environ.get("DATABASE_URL")
if not database_url:
    logger.warning("متغير DATABASE_URL غير موجود. استخدام قاعدة بيانات SQLite المحلية.")
    database_url = "sqlite:///pdf_bot.db"

app.config["SQLALCHEMY_DATABASE_URI"] = database_url
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)  # لاستخدام URL الآمن

# إعداد حجم تحميل الملفات (50 ميجابايت)
app.config['MAX_CONTENT_LENGTH'] = 50 * 1024 * 1024

# تنظيم مجلدات التحميل والتخزين المؤقت
UPLOAD_FOLDER = os.path.join(os.getcwd(), 'uploads')
TEMP_FOLDER = os.path.join(os.getcwd(), 'temp')
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(TEMP_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['TEMP_FOLDER'] = TEMP_FOLDER

# إنشاء كائن قاعدة البيانات
db = SQLAlchemy(app)

# الطرق والواجهات
@app.route('/')
def index():
    """الصفحة الرئيسية"""
    return render_template('index.html')

@app.route('/dashboard')
def dashboard():
    """لوحة التحكم"""
    return render_template('dashboard.html')

@app.route('/features')
def features():
    """صفحة الميزات"""
    return render_template('features.html')

@app.route('/api/stats')
def api_stats():
    """واجهة برمجة لإحصائيات النظام"""
    # ستتم إضافة هذه الوظيفة لاحقاً
    stats = {
        'users_count': 0,
        'documents_count': 0,
        'total_conversions': 0,
        'server_status': 'online',
        'bot_status': 'online',
        'server_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    }
    return jsonify(stats)

@app.errorhandler(404)
def page_not_found(e):
    """معالجة الصفحات غير الموجودة"""
    return render_template('404.html'), 404

@app.errorhandler(500)
def server_error(e):
    """معالجة أخطاء الخادم"""
    logger.error(f"خطأ في الخادم: {e}")
    return render_template('500.html'), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
@app.route('/download_all')
def download_all():
    # إنشاء ملف ZIP في الذاكرة
    memory_file = io.BytesIO()
    with zipfile.ZipFile(memory_file, 'w', zipfile.ZIP_DEFLATED) as zipf:
        # إضافة كل الملفات الرئيسية
        files_to_zip = [
            'main.py', 'app.py', 'bot.py', 'models.py',
            'simple_telegram_bot.py', 'run_bot.py'
        ]
        
        # إضافة المجلدات
        folders_to_zip = ['pdf_bot', 'static', 'templates']
        
        # إضافة الملفات الفردية
        for file in files_to_zip:
            if os.path.exists(file):
                zipf.write(file)
        
        # إضافة المجلدات
        for folder in folders_to_zip:
            for root, dirs, files in os.walk(folder):
                for file in files:
                    file_path = os.path.join(root, file)
                    zipf.write(file_path)
    
    # إعادة مؤشر الملف إلى البداية
    memory_file.seek(0)
    
    return send_file(
        memory_file,
        download_name='pdf_bot_files.zip',
        as_attachment=True,
        mimetype='application/zip'
    )
