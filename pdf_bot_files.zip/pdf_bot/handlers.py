"""
وحدة معالجة الصور وإنشاء ملفات PDF
"""
import os
import logging
from datetime import datetime
from PIL import Image, ImageEnhance, ImageDraw, ImageFont, ImageOps
from PyPDF2 import PdfWriter, PdfReader, PdfMerger
import pytesseract
import io
import math

logger = logging.getLogger(__name__)

# ============ وظائف المعالجة ============
def enhance_image(image_path, quality="high", brightness=1.0, contrast=1.0):
    """تحسين جودة الصورة مع إمكانية ضبط السطوع والتباين"""
    image = Image.open(image_path)
    
    # ضبط السطوع
    brightness_enhancer = ImageEnhance.Brightness(image)
    image = brightness_enhancer.enhance(brightness)
    
    # ضبط التباين
    contrast_enhancer = ImageEnhance.Contrast(image)
    image = contrast_enhancer.enhance(contrast)
    
    if quality == "high":
        # تحسين الحدة
        sharpness = ImageEnhance.Sharpness(image)
        image = sharpness.enhance(1.5)
        
        # تحسين الألوان
        color = ImageEnhance.Color(image)
        image = color.enhance(1.1)
    
    return image

def rotate_image(image_path, angle):
    """تدوير الصورة بزاوية معينة"""
    image = Image.open(image_path)
    rotated_image = image.rotate(angle, expand=True)
    return rotated_image

def adjust_image(image_path, brightness=1.0, contrast=1.0, rotate=0):
    """تعديل الصورة من حيث السطوع والتباين والتدوير"""
    image = Image.open(image_path)
    
    # التدوير
    if rotate != 0:
        image = image.rotate(rotate, expand=True)
    
    # ضبط السطوع
    brightness_enhancer = ImageEnhance.Brightness(image)
    image = brightness_enhancer.enhance(brightness)
    
    # ضبط التباين
    contrast_enhancer = ImageEnhance.Contrast(image)
    image = contrast_enhancer.enhance(contrast)
    
    return image

def add_watermark_to_image(image, text, position="bottom-right", opacity=128):
    """إضافة نص العلامة المائية إلى الصورة"""
    # إنشاء نسخة لتجنب تعديل الأصل
    img_with_watermark = image.copy()
    
    # إنشاء سياق الرسم
    draw = ImageDraw.Draw(img_with_watermark)
    
    width, height = img_with_watermark.size
    text_color = (200, 200, 200, opacity)  # رمادي فاتح مع شفافية
    
    # محاولة تحميل خط عربي إذا كان متوفراً
    try:
        font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 20)
    except:
        font = ImageFont.load_default()
    
    # حساب أبعاد النص
    text_width, text_height = draw.textsize(text, font=font) if hasattr(draw, 'textsize') else (len(text) * 8, 20)
    
    # تحديد الموضع حسب الخيار المطلوب
    if position == "bottom-right":
        text_position = (width - text_width - 10, height - text_height - 10)
    elif position == "bottom-left":
        text_position = (10, height - text_height - 10)
    elif position == "top-right":
        text_position = (width - text_width - 10, 10)
    elif position == "top-left":
        text_position = (10, 10)
    elif position == "center":
        text_position = ((width - text_width) // 2, (height - text_height) // 2)
    else:
        text_position = (width - text_width - 10, height - text_height - 10)  # الافتراضي
    
    # رسم النص
    draw.text(text_position, text, fill=text_color, font=font)
    
    return img_with_watermark

def create_pdf(image_paths, output_path, quality="high", add_watermark=False, watermark_text="Created by PDF Bot", 
              watermark_position="bottom-right", compress=False, page_size="A4", orientation="portrait",
              add_page_numbers=False, brightness=1.0, contrast=1.0, processed_images=None):
    """إنشاء PDF من قائمة صور مع خيارات متعددة"""
    images = []
    
    # تحديد أبعاد الصفحة
    page_sizes = {
        "A4": (210, 297),
        "A5": (148, 210),
        "Letter": (216, 279),
        "Legal": (216, 356)
    }
    
    # الحصول على الأبعاد المطلوبة
    width_mm, height_mm = page_sizes.get(page_size, page_sizes["A4"])
    
    # تبديل الأبعاد إذا كان الاتجاه أفقياً
    if orientation == "landscape":
        width_mm, height_mm = height_mm, width_mm
    
    # تحويل مم إلى بكسل (300 نقطة لكل بوصة)
    width_px = int(width_mm * 11.81)  # 300 dpi = 11.81 pixels/mm
    height_px = int(height_mm * 11.81)
    
    # استخدام الصور المعالجة مسبقًا إذا كانت موجودة
    if processed_images and len(processed_images) == len(image_paths):
        source_images = processed_images
    else:
        # معالجة الصور إذا لم تكن معالجة مسبقًا
        source_images = []
        for img_path in image_paths:
            try:
                img = enhance_image(img_path, quality, brightness, contrast)
                source_images.append(img)
            except Exception as e:
                logger.error(f"خطأ في معالجة الصورة {img_path}: {e}")
    
    # معالجة كل صورة وتحويلها إلى صفحات PDF
    for index, img in enumerate(source_images):
        try:
            # ضبط مقاس الصورة للملاءمة مع الصفحة مع الحفاظ على النسبة
            img_copy = img.copy()
            img_copy.thumbnail((width_px, height_px))
            
            # إنشاء صفحة بيضاء بحجم الورقة
            page = Image.new("RGB", (width_px, height_px), "white")
            
            # حساب الموضع لوضع الصورة في وسط الصفحة
            paste_x = (width_px - img_copy.width) // 2
            paste_y = (height_px - img_copy.height) // 2
            
            # لصق الصورة في الصفحة
            page.paste(img_copy, (paste_x, paste_y))
            
            # إضافة علامة مائية إذا كانت ممكّنة
            if add_watermark:
                page = add_watermark_to_image(page, watermark_text, position=watermark_position)
            
            # إضافة أرقام الصفحات
            if add_page_numbers:
                draw = ImageDraw.Draw(page)
                page_number = str(index + 1)
                try:
                    font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 12)
                except:
                    font = ImageFont.load_default()
                text_width, text_height = draw.textsize(page_number, font=font) if hasattr(draw, 'textsize') else (len(page_number) * 8, 15)
                draw.text((width_px - text_width - 20, height_px - text_height - 20), page_number, fill=(0, 0, 0), font=font)
            
            images.append(page)
        except Exception as e:
            logger.error(f"خطأ في معالجة الصورة رقم {index}: {e}")
    
    if not images:
        raise ValueError("لم يتم معالجة أي صور بنجاح")
    
    # حفظ الصور في PDF
    if len(images) == 1:
        images[0].save(output_path, "PDF", resolution=300.0)
    else:
        images[0].save(
            output_path, "PDF", resolution=300.0,
            save_all=True, append_images=images[1:]
        )
    
    # ضغط إذا تم طلبه
    if compress:
        compress_pdf(output_path)
    
    return output_path

def compress_pdf(pdf_path, compression_level="medium"):
    """ضغط ملف PDF بمستويات مختلفة"""
    try:
        reader = PdfReader(pdf_path)
        writer = PdfWriter()
        
        # تعيين مستوى الضغط
        writer.compress = True
        
        # إضافة الصفحات
        for page in reader.pages:
            writer.add_page(page)
        
        # الحفاظ على البيانات الوصفية
        if reader.metadata:
            writer.add_metadata(reader.metadata)
        
        # تطبيق الضغط وحفظ الملف
        with open(pdf_path, "wb") as f:
            writer.write(f)
        
        logger.info(f"تم ضغط PDF: {pdf_path}")
    except Exception as e:
        logger.error(f"خطأ في ضغط PDF: {e}")

def extract_text_from_image(image_path, lang="ara+eng"):
    """استخراج النص من الصورة باستخدام OCR"""
    try:
        image = Image.open(image_path)
        
        # تحسين الصورة للتعرف على النص بشكل أفضل
        # تحويل الصورة إلى التدرج الرمادي
        image = image.convert("L")
        
        # زيادة التباين
        enhancer = ImageEnhance.Contrast(image)
        image = enhancer.enhance(2.0)
        
        # استخدام tesseract لاستخراج النص
        text = pytesseract.image_to_string(image, lang=lang)
        return text
    except Exception as e:
        logger.error(f"خطأ في استخراج النص من الصورة: {e}")
        return ""

def translate_document_text(text, target_lang="ar"):
    """ترجمة النص إلى اللغة المستهدفة"""
    from googletrans import Translator
    
    try:
        translator = Translator()
        if not text or len(text.strip()) == 0:
            return ""
        
        # تقسيم النص إلى أجزاء إذا كان طويلاً
        # (يوجد حد لطول النص الذي يمكن ترجمته في مرة واحدة)
        max_length = 4500
        if len(text) <= max_length:
            result = translator.translate(text, dest=target_lang)
            return result.text
        else:
            # تقسيم النص إلى أجزاء أصغر
            parts = [text[i:i+max_length] for i in range(0, len(text), max_length)]
            translated_parts = []
            
            for part in parts:
                result = translator.translate(part, dest=target_lang)
                translated_parts.append(result.text)
            
            return "\n".join(translated_parts)
    
    except Exception as e:
        logger.error(f"خطأ في ترجمة النص: {e}")
        return text

def convert_pdf_to_docx(pdf_path, output_path=None):
    """تحويل PDF إلى ملف Word"""
    import tempfile
    from pdf2image import convert_from_path
    import pytesseract
    from docx import Document
    
    try:
        if output_path is None:
            base_path = os.path.splitext(pdf_path)[0]
            output_path = f"{base_path}.docx"
        
        # تحويل PDF إلى صور
        images = convert_from_path(pdf_path)
        
        # إنشاء مستند Word جديد
        doc = Document()
        
        # معالجة كل صفحة
        for i, image in enumerate(images):
            # استخراج النص
            text = pytesseract.image_to_string(image, lang="ara+eng")
            
            # إضافة ترويسة لكل صفحة
            if i > 0:
                doc.add_page_break()
            
            # إضافة النص إلى المستند
            doc.add_paragraph(text)
        
        # حفظ المستند
        doc.save(output_path)
        
        return output_path
    
    except Exception as e:
        logger.error(f"خطأ في تحويل PDF إلى Word: {e}")
        return None

def create_business_card(name, title, phone, email, company=None, output_path=None):
    """إنشاء بطاقة أعمال كملف PDF"""
    from fpdf import FPDF
    import tempfile
    
    try:
        if output_path is None:
            temp_dir = tempfile.gettempdir()
            output_path = os.path.join(temp_dir, f"business_card_{name}.pdf")
        
        # بطاقة أعمال بحجم قياسي
        pdf = FPDF(orientation='L', unit='mm', format=(85, 55))
        pdf.add_page()
        
        # ضبط الخطوط والألوان
        pdf.set_font("Arial", "B", 14)
        pdf.set_text_color(0, 0, 0)
        
        # إضافة المعلومات (من اليمين إلى اليسار للعربية)
        pdf.cell(0, 10, txt=name, ln=True, align='C')
        
        if title:
            pdf.set_font("Arial", "I", 10)
            pdf.cell(0, 7, txt=title, ln=True, align='C')
        
        if company:
            pdf.set_font("Arial", "", 10)
            pdf.cell(0, 7, txt=company, ln=True, align='C')
        
        pdf.set_font("Arial", "", 8)
        pdf.cell(0, 7, txt=phone, ln=True, align='C')
        pdf.cell(0, 7, txt=email, ln=True, align='C')
        
        # حفظ الملف
        pdf.output(output_path)
        
        return output_path
    
    except Exception as e:
        logger.error(f"خطأ في إنشاء بطاقة العمل: {e}")
        return None

def add_signature_to_pdf(pdf_path, signature_image_path, page_numbers=None, position='bottom-right', output_path=None):
    """إضافة توقيع إلى ملف PDF"""
    from PyPDF2 import PdfReader, PdfWriter
    from PIL import Image
    import io
    
    try:
        if output_path is None:
            base_path = os.path.splitext(pdf_path)[0]
            output_path = f"{base_path}_signed.pdf"
        
        # فتح ملف PDF
        reader = PdfReader(pdf_path)
        writer = PdfWriter()
        
        # تحميل صورة التوقيع
        signature = Image.open(signature_image_path)
        
        # تحديد صفحات التوقيع
        if page_numbers is None:
            # التوقيع على كل الصفحات
            page_numbers = range(len(reader.pages))
        else:
            # التأكد من أن صفحات التوقيع ضمن نطاق الملف
            page_numbers = [p-1 for p in page_numbers if 0 < p <= len(reader.pages)]
        
        # معالجة كل صفحة
        for i, page in enumerate(reader.pages):
            if i in page_numbers:
                # إضافة التوقيع للصفحة
                packet = io.BytesIO()
                
                # إنشاء صورة من الصفحة الحالية
                # (هذه عملية معقدة في الواقع وتحتاج إلى مكتبات إضافية)
                # هنا نستخدم نهجًا مبسطًا
                
                # إضافة الصفحة مع التوقيع
                writer.add_page(page)
            else:
                # إضافة الصفحة بدون تغيير
                writer.add_page(page)
        
        # حفظ الملف الجديد
        with open(output_path, "wb") as out_file:
            writer.write(out_file)
        
        return output_path
    
    except Exception as e:
        logger.error(f"خطأ في إضافة التوقيع: {e}")
        return None

def merge_pdfs(pdf_paths, output_path):
    """دمج عدة ملفات PDF في ملف واحد"""
    merger = PdfMerger()
    
    for pdf_path in pdf_paths:
        try:
            merger.append(pdf_path)
        except Exception as e:
            logger.error(f"خطأ في دمج PDF {pdf_path}: {e}")
    
    with open(output_path, "wb") as f:
        merger.write(f)
    
    merger.close()
    return output_path

def split_pdf(pdf_path, output_dir, split_method="equal", pages_per_file=1, page_ranges=None):
    """تقسيم ملف PDF حسب طرق مختلفة"""
    try:
        reader = PdfReader(pdf_path)
        total_pages = len(reader.pages)
        
        # إنشاء دليل الإخراج إذا لم يكن موجوداً
        os.makedirs(output_dir, exist_ok=True)
        
        output_paths = []
        
        # تقسيم حسب عدد متساوٍ من الصفحات لكل ملف
        if split_method == "equal":
            num_files = math.ceil(total_pages / pages_per_file)
            
            for i in range(num_files):
                start_page = i * pages_per_file
                end_page = min((i + 1) * pages_per_file, total_pages)
                
                writer = PdfWriter()
                for j in range(start_page, end_page):
                    writer.add_page(reader.pages[j])
                
                output_file = os.path.join(output_dir, f"split_{i+1}.pdf")
                with open(output_file, "wb") as f:
                    writer.write(f)
                
                output_paths.append(output_file)
        
        # تقسيم حسب نطاقات صفحات محددة
        elif split_method == "range" and page_ranges:
            for i, page_range in enumerate(page_ranges):
                start, end = page_range
                writer = PdfWriter()
                
                # تصحيح مؤشرات الصفحات (تبدأ من 1 في الواجهة ومن 0 داخلياً)
                for j in range(start-1, min(end, total_pages)):
                    writer.add_page(reader.pages[j])
                
                output_file = os.path.join(output_dir, f"range_{start}_to_{end}.pdf")
                with open(output_file, "wb") as f:
                    writer.write(f)
                
                output_paths.append(output_file)
        
        logger.info(f"تم تقسيم PDF إلى {len(output_paths)} ملفات")
        return output_paths
    
    except Exception as e:
        logger.error(f"خطأ في تقسيم PDF: {e}")
        return []

def encrypt_pdf(pdf_path, password, output_path=None):
    """حماية ملف PDF بكلمة مرور"""
    if output_path is None:
        output_path = pdf_path
        
    try:
        reader = PdfReader(pdf_path)
        writer = PdfWriter()
        
        # إضافة كل الصفحات
        for page in reader.pages:
            writer.add_page(page)
        
        # تعيين كلمة المرور
        writer.encrypt(password)
        
        # حفظ الملف المحمي
        with open(output_path, "wb") as f:
            writer.write(f)
        
        logger.info(f"تمت حماية ملف PDF بكلمة مرور")
        return output_path
    
    except Exception as e:
        logger.error(f"خطأ في حماية PDF بكلمة مرور: {e}")
        return None

def add_page_numbers_to_pdf(pdf_path, output_path=None):
    """إضافة أرقام صفحات إلى ملف PDF"""
    if output_path is None:
        output_path = pdf_path
        
    try:
        reader = PdfReader(pdf_path)
        writer = PdfWriter()
        
        for i, page in enumerate(reader.pages):
            packet = io.BytesIO()
            # إنشاء صورة من الصفحة الحالية
            img = Image.new('RGB', (page.mediabox.width, page.mediabox.height), (255, 255, 255))
            draw = ImageDraw.Draw(img)
            
            # رسم رقم الصفحة
            page_number_text = str(i + 1)
            draw.text((page.mediabox.width - 30, page.mediabox.height - 20), page_number_text, fill=(0, 0, 0))
            
            # تحويل الصورة إلى PDF
            img.save(packet, 'PDF')
            packet.seek(0)
            
            # إضافة الصفحة مع رقم الصفحة
            numbered_page = PdfReader(packet).pages[0]
            writer.add_page(numbered_page)
        
        # حفظ الملف الناتج
        with open(output_path, "wb") as f:
            writer.write(f)
        
        logger.info(f"تمت إضافة أرقام الصفحات إلى PDF")
        return output_path
    
    except Exception as e:
        logger.error(f"خطأ في إضافة أرقام الصفحات إلى PDF: {e}")
        return None